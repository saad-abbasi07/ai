// AiViqo Chatbot Knowledge Base and Logic
class AiViqoChatbot {
    constructor() {
        this.isOpen = false;
        this.currentFlow = null;
        this.userContext = {};
        this.responses = this.initializeResponses();
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        // Lead form submission
        const leadForm = document.getElementById('lead-form');
        if (leadForm) {
            leadForm.addEventListener('submit', (e) => this.handleLeadSubmission(e));
        }
    }

    initializeResponses() {
        return {
            greetings: [
                "Hi! I'm your AiViqo Assistant. How can I help you today?",
                "Hello! Welcome to AiViqo. What would you like to know about our AI automation services?",
                "Hey there! I'm here to help you discover how AiViqo can automate your business processes. What interests you?"
            ],
            services: {
                general: "AiViqo specializes in 5 core areas:\n\n🔧 **AI Workflow Automation** - Automate repetitive tasks and connect your tools\n\n💬 **AI Voice & Chat Agents** - Build intelligent agents for customer interaction\n\n📱 **WhatsApp & Instagram Bots** - Fully automated messaging with custom logic\n\n☁️ **SaaS Automation** - Integrate and automate your favorite platforms\n\n🤖 **Custom Chatbot Builders** - Tailored chatbots for websites and apps\n\nWhich service interests you most?",
                
                'workflow-automation': "Our **AI Workflow Automation** service helps you:\n\n✅ Automate repetitive tasks\n✅ Connect CRMs, sheets, forms, and emails\n✅ Create custom workflows\n✅ Save hours of manual work daily\n\nTypical automation takes 1-2 weeks to implement. Would you like to book a demo to see how this works for your business?",
                
                'voice-chat-agents': "Our **AI Voice & Chat Agents** can:\n\n🗣️ Speak with leads naturally\n❓ Answer customer questions 24/7\n📅 Book appointments automatically\n🎯 Qualify leads intelligently\n\nThese agents integrate with your existing systems. Interested in seeing a live demo?",
                
                'whatsapp-instagram': "Our **WhatsApp & Instagram Bot** services include:\n\n📲 Automated DM responses\n🎯 Custom business logic\n📊 Lead qualification\n🔄 CRM integration\n⚡ Instant customer support\n\nPerfect for e-commerce and service businesses. Want to see how this could work for you?",
                
                'saas-automation': "Our **SaaS Automation** connects your tools:\n\n🔗 Zapier-style integrations\n📈 Advanced workflow logic\n🎯 Custom API connections\n⚡ Real-time data sync\n📊 Automated reporting\n\nWe work with 100+ popular platforms. What tools do you currently use?",
                
                'custom-chatbot': "Our **Custom Chatbot** solutions offer:\n\n🎨 Tailored design & personality\n🧠 Advanced AI logic\n🔗 Multi-platform deployment\n📊 Analytics & insights\n🔄 CRM integration\n\nBuilt for websites, apps, and messaging platforms. Ready to get started?"
            },
            
            about: "**About AiViqo:**\n\n🚀 We're a next-gen AI automation agency that helps businesses save time, reduce manual work, and grow faster using smart AI tools.\n\n👨‍💼 **Founded by:** Adnan Fida\n\n**Our Expert Team:**\n• Shahzaib Azizwani - AI Automation Specialist\n• Muhammad Jameel - AI Automation Expert\n\n🌟 We've helped 100+ businesses automate their processes and scale efficiently. What automation challenge can we solve for you?",
            
            pricing: "Our pricing depends on the specific automation you need:\n\n💼 **Consultation:** Free initial assessment\n🔧 **Simple Automations:** Starting from $500\n🤖 **Custom Chatbots:** Starting from $1,000\n🚀 **Complex Workflows:** Custom pricing\n\nEach project includes setup, testing, and 30-day support. Would you like a personalized quote? I can collect some details and have our team prepare a custom proposal.",
            
            demo: "Great! I'd love to book a demo for you. Our demos typically cover:\n\n✅ Live automation examples\n✅ Custom solution walkthrough  \n✅ ROI analysis for your business\n✅ Implementation timeline\n\n📅 **Available:** Mon-Sat, 10 AM - 10 PM (PKT)\n\nWould you like me to collect your details so our team can reach out to schedule?",
            
            timeline: "Here are typical timelines for our services:\n\n⚡ **Simple Automations:** 3-7 days\n🤖 **Custom Chatbots:** 1-2 weeks\n🔧 **Workflow Automation:** 1-2 weeks\n🎯 **Complex Systems:** 2-4 weeks\n\nAll projects include testing and revisions. The exact timeline depends on your specific requirements. Want to discuss your project?",
            
            technology: "We use cutting-edge AI technology:\n\n🤖 **OpenAI GPT Models** for natural conversations\n🧠 **Custom AI Models** for specific use cases\n⚡ **API Integrations** with 100+ platforms\n🔗 **Webhook Systems** for real-time processing\n☁️ **Cloud Infrastructure** for scalability\n\nOur solutions are built to be reliable, scalable, and future-proof. Any specific tech questions?",
            
            support: "**AiViqo Support:**\n\n📧 **Email:** info@aiviqo.com\n⏰ **Hours:** Mon-Sat, 10 AM - 10 PM (PKT)\n🌐 **Website:** aiviqo.com\n\n**What we offer:**\n✅ Free consultation\n✅ Technical support\n✅ Custom solutions\n✅ Implementation guidance\n\nWould you like me to connect you with a human specialist right now?",
            
            contact: "**Get in Touch:**\n\n📧 **Email:** info@aiviqo.com\n🌐 **Website:** aiviqo.com\n⏰ **Business Hours:** Mon-Sat, 10 AM - 10 PM (PKT)\n\n**Quick Actions:**\n• Book a free consultation\n• Get a custom quote\n• Speak with our team\n\nWhat would you prefer?"
        };
    }

    toggleChat() {
        const chatWindow = document.getElementById('chat-window');
        const chatIcon = document.getElementById('chat-icon');
        const closeIcon = document.getElementById('close-icon');
        
        this.isOpen = !this.isOpen;
        
        if (this.isOpen) {
            chatWindow.classList.add('active');
            chatIcon.style.display = 'none';
            closeIcon.style.display = 'block';
        } else {
            chatWindow.classList.remove('active');
            chatIcon.style.display = 'block';
            closeIcon.style.display = 'none';
        }
    }

    openChat(flow = null) {
        if (!this.isOpen) {
            this.toggleChat();
        }
        
        if (flow) {
            this.currentFlow = flow;
            setTimeout(() => {
                if (flow === 'demo') {
                    this.addBotMessage(this.responses.demo);
                    this.showQuickReplies(['collect-lead', 'pricing', 'support']);
                }
            }, 500);
        }
    }

    addBotMessage(message) {
        const messagesContainer = document.getElementById('chat-messages');
        
        // Show typing indicator
        this.showTypingIndicator();
        
        setTimeout(() => {
            this.hideTypingIndicator();
            
            // Clean message from markdown formatting
            const cleanMessage = message.replace(/\*\*/g, '').replace(/\*/g, '');
            
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message bot-message';
            messageDiv.innerHTML = `
                <div class="message-content">
                    <p></p>
                </div>
            `;
            
            messagesContainer.appendChild(messageDiv);
            
            // Start typing effect
            this.typeMessage(messageDiv.querySelector('p'), cleanMessage);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, Math.random() * 1000 + 500);
    }

    typeMessage(element, message, index = 0) {
        if (index < message.length) {
            // Handle line breaks
            if (message.substr(index, 1) === '\n') {
                element.innerHTML += '<br>';
            } else {
                element.innerHTML += message.charAt(index);
            }
            
            // Scroll to bottom as we type
            const messagesContainer = document.getElementById('chat-messages');
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // Random typing speed for more natural feel
            const typingSpeed = Math.random() * 30 + 20;
            setTimeout(() => this.typeMessage(element, message, index + 1), typingSpeed);
        }
    }

    addUserMessage(message) {
        const messagesContainer = document.getElementById('chat-messages');
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user-message';
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${message}</p>
            </div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    showTypingIndicator() {
        const messagesContainer = document.getElementById('chat-messages');
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot-message typing-indicator';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    showQuickReplies(replies) {
        const quickRepliesContainer = document.getElementById('quick-replies');
        quickRepliesContainer.innerHTML = '';
        
        const replyButtons = {
            'collect-lead': 'Get Started',
            'demo': 'Book Demo',
            'pricing': 'Get Pricing',
            'services': 'Our Services',
            'support': 'Contact Support',
            'about': 'About Us',
            'human': 'Talk to Human'
        };
        
        replies.forEach(reply => {
            if (replyButtons[reply]) {
                const button = document.createElement('button');
                button.className = 'quick-reply';
                button.innerHTML = `<span>${replyButtons[reply]}</span>`;
                button.onclick = () => this.selectQuickReply(reply);
                quickRepliesContainer.appendChild(button);
            }
        });
    }

    selectQuickReply(type) {
        // Add user message
        const replyTexts = {
            'services': 'Tell me about your services',
            'demo': 'I want to book a demo',
            'pricing': 'What are your prices?',
            'support': 'I need support',
            'about': 'Tell me about AiViqo',
            'collect-lead': 'I want to get started',
            'human': 'I want to talk to a human'
        };
        
        this.addUserMessage(replyTexts[type] || type);
        this.processUserInput(type);
    }

    processUserInput(input) {
        const lowerInput = input.toLowerCase();
        
        // Clear quick replies
        document.getElementById('quick-replies').innerHTML = '';
        
        // Service-specific responses
        if (lowerInput.includes('service') || input === 'services') {
            this.addBotMessage(this.responses.services.general);
            this.showQuickReplies(['demo', 'pricing', 'collect-lead']);
            return;
        }
        
        if (lowerInput.includes('workflow') || lowerInput.includes('automation')) {
            this.addBotMessage(this.responses.services['workflow-automation']);
            this.showQuickReplies(['demo', 'collect-lead', 'pricing']);
            return;
        }
        
        if (lowerInput.includes('chatbot') || lowerInput.includes('chat')) {
            this.addBotMessage(this.responses.services['custom-chatbot']);
            this.showQuickReplies(['demo', 'collect-lead', 'pricing']);
            return;
        }
        
        if (lowerInput.includes('whatsapp') || lowerInput.includes('instagram')) {
            this.addBotMessage(this.responses.services['whatsapp-instagram']);
            this.showQuickReplies(['demo', 'collect-lead', 'pricing']);
            return;
        }
        
        if (lowerInput.includes('voice') || lowerInput.includes('agent')) {
            this.addBotMessage(this.responses.services['voice-chat-agents']);
            this.showQuickReplies(['demo', 'collect-lead', 'pricing']);
            return;
        }
        
        if (lowerInput.includes('saas')) {
            this.addBotMessage(this.responses.services['saas-automation']);
            this.showQuickReplies(['demo', 'collect-lead', 'pricing']);
            return;
        }
        
        // General responses
        if (lowerInput.includes('price') || lowerInput.includes('cost') || input === 'pricing') {
            this.addBotMessage(this.responses.pricing);
            this.showQuickReplies(['collect-lead', 'demo', 'services']);
            return;
        }
        
        if (lowerInput.includes('demo') || input === 'demo') {
            this.addBotMessage(this.responses.demo);
            this.showQuickReplies(['collect-lead', 'pricing', 'services']);
            return;
        }
        
        if (lowerInput.includes('about') || lowerInput.includes('company') || input === 'about') {
            this.addBotMessage(this.responses.about);
            this.showQuickReplies(['services', 'demo', 'collect-lead']);
            return;
        }
        
        if (lowerInput.includes('founder') || lowerInput.includes('adnan') || lowerInput.includes('fida') || lowerInput.includes('who founded') || lowerInput.includes('who started')) {
            this.addBotMessage("**AiViqo Founder:**\n\n👨‍💼 **Adnan Fida** - Founder & CEO of AiViqo\n\nAdnan founded AiViqo to help businesses harness the power of AI automation. Under his leadership, we've helped 100+ companies streamline their operations and scale efficiently.\n\n🌟 Want to learn more about our team or services?");
            this.showQuickReplies(['about', 'services', 'demo']);
            return;
        }
        
        if (lowerInput.includes('team') || lowerInput.includes('members') || lowerInput.includes('shahzaib') || lowerInput.includes('jameel') || lowerInput.includes('who works')) {
            this.addBotMessage("**Meet the AiViqo Team:**\n\n👨‍💼 **Adnan Fida** - Founder & CEO\n\n🤖 **Shahzaib Azizwani** - AI Automation Specialist\nExpert in workflow automation and AI integrations\n\n⚡ **Muhammad Jameel** - AI Automation Expert\nSpecializes in custom AI solutions and chatbot development\n\nTogether, we've automated processes for 100+ businesses. Ready to see what we can do for you?");
            this.showQuickReplies(['services', 'demo', 'collect-lead']);
            return;
        }
        
        if (lowerInput.includes('support') || lowerInput.includes('help') || input === 'support') {
            this.addBotMessage(this.responses.support);
            this.showQuickReplies(['human', 'services', 'demo']);
            return;
        }
        
        if (lowerInput.includes('contact') || input === 'contact') {
            this.addBotMessage(this.responses.contact);
            this.showQuickReplies(['collect-lead', 'human', 'demo']);
            return;
        }
        
        if (lowerInput.includes('time') || lowerInput.includes('long') || lowerInput.includes('timeline')) {
            this.addBotMessage(this.responses.timeline);
            this.showQuickReplies(['demo', 'collect-lead', 'pricing']);
            return;
        }
        
        if (lowerInput.includes('technology') || lowerInput.includes('openai') || lowerInput.includes('model')) {
            this.addBotMessage(this.responses.technology);
            this.showQuickReplies(['services', 'demo', 'collect-lead']);
            return;
        }
        
        if (lowerInput.includes('start') || input === 'collect-lead') {
            this.showLeadModal();
            return;
        }
        
        if (lowerInput.includes('human') || lowerInput.includes('person') || input === 'human') {
            this.addBotMessage("I'll connect you with our team right away!\n\n📧 **Email us:** info@aiviqo.com\n⏰ **Available:** Mon-Sat, 10 AM - 10 PM (PKT)\n\nOr share your contact details and we'll reach out within an hour!");
            this.showQuickReplies(['collect-lead', 'services']);
            return;
        }
        
        // Greetings
        if (lowerInput.includes('hello') || lowerInput.includes('hi') || lowerInput.includes('hey')) {
            this.addBotMessage(this.responses.greetings[Math.floor(Math.random() * this.responses.greetings.length)]);
            this.showQuickReplies(['services', 'demo', 'pricing', 'about']);
            return;
        }
        
        // Default response for unrecognized input
        this.addBotMessage("I'd be happy to help! Here are some things I can assist you with:\n\n🔧 **Our Services** - Learn about AI automation solutions\n📅 **Book Demo** - Schedule a free consultation\n💰 **Pricing** - Get cost estimates\n🏢 **About Us** - Learn about AiViqo\n🆘 **Support** - Get technical help\n\nWhat interests you most?");
        this.showQuickReplies(['services', 'demo', 'pricing', 'support']);
    }

    sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (message) {
            this.addUserMessage(message);
            input.value = '';
            
            setTimeout(() => {
                this.processUserInput(message);
            }, 500);
        }
    }

    handleKeyPress(event) {
        if (event.key === 'Enter') {
            this.sendMessage();
        }
    }

    showLeadModal() {
        const modal = document.getElementById('lead-modal');
        modal.classList.add('active');
        this.addBotMessage("Perfect! I've opened a form for you. Please fill in your details so our team can provide you with a personalized solution.");
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('active');
    }

    handleLeadSubmission(event) {
        event.preventDefault();
        
        const formData = {
            name: document.getElementById('lead-name').value,
            email: document.getElementById('lead-email').value,
            business: document.getElementById('lead-business').value,
            service: document.getElementById('lead-service').value,
            contact: document.getElementById('lead-contact').value
        };
        
        // Store lead data (in real implementation, send to server)
        console.log('Lead submitted:', formData);
        
        // Close modal
        this.closeModal('lead-modal');
        
        // Thank user
        this.addBotMessage(`Thank you, ${formData.name}! 🎉\n\nYour information has been received. Our team will contact you within 24 hours via ${formData.contact}.\n\n**Next Steps:**\n1. We'll review your requirements\n2. Prepare a custom solution\n3. Schedule a demo call\n4. Provide a detailed proposal\n\nAnything else I can help you with today?`);
        
        this.showQuickReplies(['services', 'pricing', 'support']);
        
        // Reset form
        document.getElementById('lead-form').reset();
        
        // In real implementation, you would send this data to your server
        // this.submitLeadToServer(formData);
    }
}

// Initialize chatbot
const chatbot = new AiViqoChatbot();

// Global functions for HTML onclick events
function toggleChat() {
    chatbot.toggleChat();
}

function openChat(flow) {
    chatbot.openChat(flow);
}

function selectQuickReply(type) {
    chatbot.selectQuickReply(type);
}

function sendMessage() {
    chatbot.sendMessage();
}

function handleKeyPress(event) {
    chatbot.handleKeyPress(event);
}

function closeModal(modalId) {
    chatbot.closeModal(modalId);
}

// Auto-initialize quick replies on page load
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        chatbot.showQuickReplies(['services', 'demo', 'pricing', 'support']);
    }, 1000);
});